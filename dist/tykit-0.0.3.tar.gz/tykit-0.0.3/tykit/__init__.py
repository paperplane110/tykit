'''
Description: 
version: 
Author: TianyuYuan
Date: 2021-04-02 15:40:39
LastEditors: TianyuYuan
LastEditTime: 2021-04-02 18:38:00
'''
name = "tykit"
from tykit import *

if __name__ == "__main__":
    rlog = RLog()
    rlog.start('sdlf')