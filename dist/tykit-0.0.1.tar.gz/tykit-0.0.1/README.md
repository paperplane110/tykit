<!--
 * @Description: 
 * @version: 
 * @Author: TianyuYuan
 * @Date: 2021-04-02 15:42:10
 * @LastEditors: TianyuYuan
 * @LastEditTime: 2021-04-02 16:02:59
-->
# tykit (Tell You kit)

## Description
'Tell You kit' is a toolkit to monitor your scripts' status easily, which haves rich and pretty output for progress bar and console logs.
The tykit may support more decent output in the future

## Features
...